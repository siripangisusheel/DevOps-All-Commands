# Ansible-
simple yaml scripts 
how to rename, untar, create a file/folder and install java 
